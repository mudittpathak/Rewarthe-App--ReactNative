Rewarthe 

![AllInOne](https://github.com/jayp0234/rewarthe-app-reactnative/assets/77848783/db329f82-eef5-4957-ac72-24c5fbe5856d)

It is an app made on React-Native and is supported on multiple plateforms like ios and android.

  Steps to Run:
  1  Install node dependencies using npm i in the root directory of the app in terminal.
  2  Type npx expo start in the root directory of the app of the terminal.
  3  On you mobile scan the code which will appear on in terminal screen.
  4  And Login or Signup accordingly using the credentials.
  5  You are ready to Go.
