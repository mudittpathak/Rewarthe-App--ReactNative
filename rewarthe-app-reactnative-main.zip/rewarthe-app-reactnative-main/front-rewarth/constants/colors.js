const COLOURS = {
    white: '#FFFFFF',
    black: '#222222',
    light: '#F2F1EF',
    dark: '#1B1464',
    dprimary: '#F9690E',
    dsecondary: '#22A7F0',
    primary: '#22A7F0',
    secondary: '#F9690E',
    grey:'#CCCCCC',
    dull:'#616C6F',
    bg:'#EAF0F1',
    
}

export default COLOURS