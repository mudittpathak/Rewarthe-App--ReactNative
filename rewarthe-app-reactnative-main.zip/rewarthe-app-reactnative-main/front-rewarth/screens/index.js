import Login from "./Login";
import Signup from "./Signup";
import Welcome from "./Welcome";
import Home from "./Home";
import TC from "./TC";
import BarcodeScreen from "./BarcodeScreen";
import ProfileScreen from "./ProfileScreen";
import History from "./History"

export { Login, Signup, Welcome, Home, TC, BarcodeScreen, ProfileScreen, History };
